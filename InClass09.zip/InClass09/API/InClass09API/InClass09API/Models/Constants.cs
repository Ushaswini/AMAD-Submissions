﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InClass09API.Models
{
    public class Constants
    {
        public const int NUMBER_OF_USERS_PER_PAGE = 50;
    }
}